# Supabase Cleanup Plan

Do not run `supabase_reset.sql` against your live project.

This app currently depends on a schema contract that is wider than the original reset script:

- `app_config` is read and written as a row with top-level pricing columns plus nested JSON sections.
- `equipment_specs` writes `width_ft`, `height_ft`, and `source` from the search API.
- `quote_logs` inserts `notes` from the client approval flow.
- `company_invites` expects `status`, token-based acceptance, and one of the three app roles: Manager, Dispatch, or Client.
- Client users do not get the settings UI, but the current app still needs company pricing/config data behind the scenes to calculate client quotes, so database read access remains broader than UI access.

Safe rollout order:

1. Create a fresh Supabase project or database branch.
2. Run `supabase_reset.sql` there first.
3. Verify these flows before touching production:
   - manager login and settings save
   - equipment lookup and Gemini persistence
   - dispatcher quote logging
   - client portal quote calculation
   - invite send, invite registration, and invite acceptance
4. Export production data before any migration.
5. Migrate production with additive changes first; only remove old columns after the app no longer reads them.

Invite flow note:

The registration flow now uses server endpoints instead of direct browser reads to `company_invites`. That lets you keep row-level security strict without exposing pending invites publicly.