-- DESTRUCTIVE: Run this only in a new Supabase project or after backing up data.
-- This schema makes company_id the tenant boundary for all company-owned data.

create extension if not exists pgcrypto;

drop table if exists public.quote_logs cascade;
drop table if exists public.quotes cascade;
drop table if exists public.clients cascade;
drop table if exists public.client_profiles cascade;
drop table if exists public.equipment_specs cascade;
drop table if exists public.company_invites cascade;
drop table if exists public.account_requests cascade;
drop table if exists public.app_config cascade;
drop table if exists public.profiles cascade;
drop table if exists public.companies cascade;

create table public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  company_code text not null unique,
  created_at timestamptz not null default now()
);

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  company_id uuid not null references public.companies(id) on delete restrict,
  email text not null,
  full_name text not null default '',
  role text not null check (role in ('manager', 'dispatch', 'client')),
  default_base_id text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, email)
);

create table public.app_config (
  company_id uuid primary key references public.companies(id) on delete cascade,
  hourly_min numeric not null default 125,
  hourly_max numeric not null default 135,
  rounding_interval numeric not null default 25,
  drive_time_buffer numeric not null default 10,
  load_unload_base_mins numeric not null default 30,
  extra_stop_mins numeric not null default 15,
  after_hours_multiplier numeric not null default 25,
  road_club_multiplier numeric not null default 15,
  metro_multiplier numeric not null default 28.57,
  hazard_multiplier numeric not null default 40,
  pricing jsonb not null default '{}'::jsonb,
  surcharges jsonb not null default '{}'::jsonb,
  geofences jsonb not null default '{}'::jsonb,
  bases jsonb not null default '[]'::jsonb,
  users jsonb not null default '[]'::jsonb,
  client_portal jsonb not null default '{}'::jsonb,
  config jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.clients (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  client_name text not null,
  contact_email text,
  contact_phone text,
  approval_threshold integer check (approval_threshold is null or approval_threshold >= 0),
  pricing jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (company_id, contact_email)
);

create table public.equipment_specs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  make text not null,
  model text not null,
  serial_number text,
  operating_weight_lbs numeric check (operating_weight_lbs is null or operating_weight_lbs >= 0),
  width_in numeric check (width_in is null or width_in > 0),
  height_in numeric check (height_in is null or height_in > 0),
  length_in numeric check (length_in is null or length_in > 0),
  width_ft numeric check (width_ft is null or width_ft > 0),
  height_ft numeric check (height_ft is null or height_ft > 0),
  length_ft numeric check (length_ft is null or length_ft > 0),
  is_heavy boolean not null default false,
  source text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.quote_logs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete restrict,
  customer_name text,
  customer_phone text,
  pickup_address text not null,
  dropoff_address text not null,
  all_waypoints jsonb not null default '[]'::jsonb,
  base_yard_id text,
  truck_class text,
  total_miles numeric check (total_miles is null or total_miles >= 0),
  total_hours numeric check (total_hours is null or total_hours >= 0),
  min_quote numeric check (min_quote is null or min_quote >= 0),
  max_quote numeric check (max_quote is null or max_quote >= 0),
  custom_quote numeric check (custom_quote is null or custom_quote >= 0),
  applied_surcharges jsonb not null default '{}'::jsonb,
  notes text,
  created_at timestamptz not null default now()
);

create table public.company_invites (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  email text not null,
  full_name text,
  role text not null check (role in ('manager', 'dispatch', 'client')),
  status text not null default 'pending' check (status in ('pending', 'accepted', 'revoked', 'expired')),
  token text not null unique default gen_random_uuid()::text,
  invited_by uuid references public.profiles(id) on delete restrict,
  accepted_by uuid references public.profiles(id) on delete set null,
  accepted_at timestamptz,
  expires_at timestamptz not null default now() + interval '7 days',
  created_at timestamptz not null default now(),
  constraint company_invites_acceptance_check check (
    (status = 'accepted' and accepted_by is not null and accepted_at is not null) or
    (status <> 'accepted' and accepted_by is null and accepted_at is null)
  )
);

create table public.account_requests (
  id uuid primary key default gen_random_uuid(),
  full_name text not null,
  company_name text not null,
  email text not null,
  phone text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected')),
  created_at timestamptz not null default now()
);

create index clients_company_id_idx on public.clients(company_id);
create index equipment_specs_company_id_idx on public.equipment_specs(company_id);
create index equipment_specs_search_idx on public.equipment_specs(lower(make), lower(model), lower(serial_number));
create index quote_logs_company_created_at_idx on public.quote_logs(company_id, created_at desc);
create index company_invites_company_id_idx on public.company_invites(company_id);
create unique index company_invites_pending_email_idx
  on public.company_invites(company_id, lower(email))
  where status = 'pending' and accepted_at is null;

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create or replace function public.my_company_id()
returns uuid
language sql
stable
security definer
set search_path = public
as $$
  select company_id
  from public.profiles
  where id = auth.uid()
$$;

create or replace function public.my_role()
returns text
language sql
stable
security definer
set search_path = public
as $$
  select role
  from public.profiles
  where id = auth.uid()
$$;

create or replace function public.is_manager()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select public.my_role() = 'manager'
$$;

create or replace function public.update_my_default_base(new_default_base_id text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  update public.profiles
  set default_base_id = new_default_base_id
  where id = auth.uid();
end;
$$;

create trigger set_profiles_updated_at
before update on public.profiles
for each row execute function public.set_updated_at();

create trigger set_app_config_updated_at
before update on public.app_config
for each row execute function public.set_updated_at();

create trigger set_clients_updated_at
before update on public.clients
for each row execute function public.set_updated_at();

create trigger set_equipment_specs_updated_at
before update on public.equipment_specs
for each row execute function public.set_updated_at();

alter table public.companies enable row level security;
alter table public.profiles enable row level security;
alter table public.app_config enable row level security;
alter table public.clients enable row level security;
alter table public.equipment_specs enable row level security;
alter table public.quote_logs enable row level security;
alter table public.company_invites enable row level security;
alter table public.account_requests enable row level security;

create policy "members can view their company"
on public.companies for select to authenticated
using (id = public.my_company_id());

create policy "members can view their profile"
on public.profiles for select to authenticated
using (id = auth.uid());

create policy "managers can view company profiles"
on public.profiles for select to authenticated
using (public.is_manager() and company_id = public.my_company_id());

create policy "managers can manage company profiles"
on public.profiles for all to authenticated
using (public.is_manager() and company_id = public.my_company_id())
with check (public.is_manager() and company_id = public.my_company_id());

create policy "company members can view company config"
on public.app_config for select to authenticated
using (company_id = public.my_company_id());

create policy "managers can manage company config"
on public.app_config for all to authenticated
using (public.is_manager() and company_id = public.my_company_id())
with check (public.is_manager() and company_id = public.my_company_id());

create policy "managers can manage company clients"
on public.clients for all to authenticated
using (public.is_manager() and company_id = public.my_company_id())
with check (public.is_manager() and company_id = public.my_company_id());

create policy "company members can read company equipment"
on public.equipment_specs for select to authenticated
using (company_id is null or company_id = public.my_company_id());

create policy "managers can manage company equipment"
on public.equipment_specs for all to authenticated
using (public.is_manager() and company_id = public.my_company_id())
with check (public.is_manager() and company_id = public.my_company_id());

create policy "dispatchers can read company quote logs"
on public.quote_logs for select to authenticated
using (company_id = public.my_company_id() and public.my_role() in ('manager', 'dispatch'));

create policy "company users can create company quote logs"
on public.quote_logs for insert to authenticated
with check (
  company_id = public.my_company_id()
  and user_id = auth.uid()
  and public.my_role() in ('manager', 'dispatch', 'client')
);

create policy "managers can read company invites"
on public.company_invites for select to authenticated
using (public.is_manager() and company_id = public.my_company_id());

create policy "managers can create company invites"
on public.company_invites for insert to authenticated
with check (
  public.is_manager()
  and company_id = public.my_company_id()
  and invited_by = auth.uid()
);

create policy "public can submit account requests"
on public.account_requests for insert to anon, authenticated
with check (status = 'pending');

grant usage on schema public to anon, authenticated;
grant select, insert on public.account_requests to anon, authenticated;
grant select on public.companies to authenticated;
grant select, update on public.profiles to authenticated;
grant select, insert, update, delete on public.app_config to authenticated;
grant select, insert, update, delete on public.clients to authenticated;
grant select, insert, update, delete on public.equipment_specs to authenticated;
grant select, insert on public.quote_logs to authenticated;
grant select, insert, update on public.company_invites to authenticated;
grant execute on function public.update_my_default_base(text) to authenticated;
