import { createClient } from '@supabase/supabase-js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const token = String(body?.token || '').trim();
    const userId = String(body?.userId || '').trim();
    const email = String(body?.email || '').trim().toLowerCase();

    if (!token || !userId || !email) {
      return res.status(400).json({ error: 'Invite token, user ID, and email are required.' });
    }

    const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
    const serviceRoleKey = process.env.VITE_SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SERVICE_ROLE_KEY;

    if (!supabaseUrl || !serviceRoleKey) {
      return res.status(500).json({ error: 'Missing Supabase service role environment variables on server.' });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    const { data: inviteData, error: inviteError } = await supabase
      .from('company_invites')
      .select('id, email, status, expires_at')
      .eq('token', token)
      .maybeSingle();

    if (inviteError) {
      throw inviteError;
    }

    if (!inviteData) {
      return res.status(404).json({ error: 'This invite is no longer valid. Please request a new one.' });
    }

    if (inviteData.status !== 'pending') {
      return res.status(409).json({ error: 'This invite is no longer valid. Please request a new one.' });
    }

    if (inviteData.expires_at && new Date(inviteData.expires_at).getTime() < Date.now()) {
      return res.status(410).json({ error: 'This invite has expired. Please request a new one.' });
    }

    if (String(inviteData.email || '').trim().toLowerCase() !== email) {
      return res.status(403).json({ error: 'This invite belongs to a different email address.' });
    }

    const { error: updateError } = await supabase
      .from('company_invites')
      .update({
        status: 'accepted',
        accepted_at: new Date().toISOString(),
        accepted_by: userId,
      })
      .eq('id', inviteData.id)
      .eq('status', 'pending');

    if (updateError) {
      throw updateError;
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Invite acceptance failed:', error);
    return res.status(500).json({ error: error.message || 'Unable to accept invite.' });
  }
}