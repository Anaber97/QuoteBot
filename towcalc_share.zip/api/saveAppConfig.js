import { createClient } from '@supabase/supabase-js';
import { getServerEnv } from './_env.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const body = typeof req.body === 'string' ? JSON.parse(req.body) : req.body || {};
    const companyId = String(body?.company_id || '').trim();
    const userId = String(body?.user_id || '').trim();
    const payload = body?.config || null;

    if (!companyId || !userId || !payload) {
      return res.status(400).json({ error: 'company_id, user_id, and config are required.' });
    }

    const supabaseUrl = getServerEnv('VITE_SUPABASE_URL') || getServerEnv('SUPABASE_URL');
    const serviceRoleKey = getServerEnv('VITE_SUPABASE_SERVICE_ROLE_KEY') || getServerEnv('SUPABASE_SERVICE_ROLE_KEY');

    if (!supabaseUrl || !serviceRoleKey) {
      return res.status(500).json({ error: 'Missing Supabase service role environment variables on server.' });
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: {
        persistSession: false,
        autoRefreshToken: false,
      },
    });

    const { data: profile, error: profileError } = await supabase
      .from('profiles')
      .select('id, company_id, role')
      .eq('id', userId)
      .single();

    if (profileError || !profile) {
      return res.status(403).json({ error: 'Unable to verify user profile for settings save.' });
    }

    if (profile.company_id !== companyId || profile.role !== 'manager') {
      return res.status(403).json({ error: 'Only managers can save company settings.' });
    }

    const toNumberOr = (value, fallback) => {
      const num = Number(value);
      return Number.isFinite(num) ? num : fallback;
    };

    const normalizedPayload = {
      ...payload,
      company_id: companyId,
      hourly_min: toNumberOr(payload?.pricing?.hourly_min ?? payload?.hourly_min, 125),
      hourly_max: toNumberOr(payload?.pricing?.hourly_max ?? payload?.hourly_max, 135),
      rounding_interval: toNumberOr(payload?.pricing?.rounding_interval ?? payload?.rounding_interval, 25),
      drive_time_buffer: toNumberOr(payload?.pricing?.drive_time_buffer ?? payload?.drive_time_buffer, 10),
      load_unload_base_mins: toNumberOr(payload?.pricing?.load_unload_base_mins ?? payload?.load_unload_base_mins, 30),
      extra_stop_mins: toNumberOr(payload?.pricing?.extra_stop_mins ?? payload?.extra_stop_mins, 15),
      after_hours_multiplier: toNumberOr(payload?.pricing?.after_hours_multiplier ?? payload?.after_hours_multiplier, 25),
      road_club_multiplier: toNumberOr(payload?.pricing?.road_club_multiplier ?? payload?.road_club_multiplier, 15),
      metro_multiplier: toNumberOr(payload?.pricing?.metro_multiplier ?? payload?.metro_multiplier, 28.57),
      hazard_multiplier: toNumberOr(payload?.pricing?.hazard_multiplier ?? payload?.hazard_multiplier, 40),
    };

    const { error: saveError } = await supabase
      .from('app_config')
      .upsert(normalizedPayload, { onConflict: 'company_id' });

    if (saveError) {
      console.error('App config save failed:', saveError);
      return res.status(500).json({ error: saveError.message || 'Failed to save app configuration.' });
    }

    return res.status(200).json({ success: true });
  } catch (error) {
    console.error('Unexpected saveAppConfig error:', error);
    return res.status(500).json({ error: error.message || 'Internal server error.' });
  }
}